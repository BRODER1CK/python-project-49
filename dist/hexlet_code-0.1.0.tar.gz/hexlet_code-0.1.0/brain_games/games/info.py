from brain_games.cli import welcome_user
import prompt


def info(games):
    name = welcome_user()
    print(games.task)
    for round in range(3):
        question, result = games.game()
        print(f"Question: {question}")
        answer = prompt.string("Your answer: ")
        if answer == question:
            print("Correct!")
        else:
            print(f"'{answer}' is wrong answer ;(. Correct answer was '{result}'")
            return print(f"Let's try again, {name}!")
    return print(f"Congratulations, {name}!")
