#!/usr/bin/env python3

def greeting():
    print("Welcome to the Brain Games!")


def main():
    greeting()


if __name__ == '__main__':
    main()
