### Hexlet tests and linter status:
[![Actions Status](https://github.com/BRODER1CK/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/BRODER1CK/python-project-49/actions)
<a href="https://codeclimate.com/github/BRODER1CK/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/bd45a93e6902729e87b0/maintainability" /></a>
Brain Even - https://asciinema.org/a/iaF3N7iNcolhpQ1y63WvwJWCQ
Brain Calc - https://asciinema.org/a/zQNFfjhtoQeG8a1KjLa5FYegV
Brain GCD - https://asciinema.org/a/BdwjhICTz6BX3ndRSQRfMkvjr
Brain Progression - https://asciinema.org/a/TotqX04zz6myqToxyYZp8x3Jp
